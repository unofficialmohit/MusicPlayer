package com.mg.music;

public interface MediaControl {
    void play(String mediaUri);
    void pause();
    void stop();
    void seekTo(int position);
}
