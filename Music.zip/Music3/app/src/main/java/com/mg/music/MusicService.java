package com.mg.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.media.app.NotificationCompat.MediaStyle;

import androidx.core.app.NotificationCompat;

public class MusicService extends Service {
    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "YourChannelId";

    @Override
    public void onCreate() {
        super.onCreate();

        // Create a notification channel if using Android Oreo or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Your Channel", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "YourChannelId");

// Set basic notification properties (icon, title, etc.)
        builder.setSmallIcon(R.drawable.musicbutton)
                .setContentTitle("Song Title")
                .setContentText("Artist Name");

// Create MediaStyle and set its properties
        NotificationCompat.MediaStyle mediaStyle = new NotificationCompat.MediaStyle();
        mediaStyle.setShowActionsInCompactView(0, 1, 2); // Indicates the order of playback actions

// Set the MediaStyle to your notification builder
        builder.setStyle(mediaStyle);

// Add playback actions to the notification
        builder.addAction(R.drawable.ic_previous, "Previous", previousPendingIntent);
        builder.addAction(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play, "Play/Pause", playPausePendingIntent);
        builder.addAction(R.drawable.ic_next, "Next", nextPendingIntent);

// Build and show the notification
        Notification notification = builder.build();
        startForeground(NOTIFICATION_ID, notification);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Your service logic goes here
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
